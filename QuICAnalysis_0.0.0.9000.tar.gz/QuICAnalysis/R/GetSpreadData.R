#' Spread Analysis Results
#'
#' @description This function takes a data frame containing metadata and analysis results, and spreads the results into a list of data frames for each analysis term.
#'
#' @param meta.w.analysis A data frame containing the metadata and results of the analysis. This should be the output from the `NormAnalysis` function.
#' @return A list of data frames containing the spread results of the analysis. Each data frame corresponds to one of the analysis terms (TimeToThreshold, RAF, MPR, MS), and contains one row for each replicate and one column for each unique content value in the metadata.
#' @importFrom magrittr %>%
#' @examples
#' \dontrun{
#' # Combine the meta_ct and analysis_ct data; meta_ct and analysis_ct are 
#' # outputs from GetCleanMeta and GetAnalysis functions, respectively.
#' meta.w.analysis_ct <- cbind(meta_ct, analysis_ct)
#'
#' # Use the data with the GetSpreadData function
#' analysis_spread_ct <- GetSpreadData(meta.w.analysis_ct)
#' print(analysis_spread_ct)
#' }
#' @export
GetSpreadData = function (meta.w.analysis) {
  analysis_spread = vector(mode = 'list')
  terms = c('TimeToThreshold', 'RAF', 'MPR','MS')
  for (j in 1:length(terms)) {
    term = terms[j]
    uname = unique(meta.w.analysis$content)
    n_rep = max(meta.w.analysis$replicate)
    #I need to make up a data to dest this 
    final_spread = matrix(NA, nrow = n_rep, ncol = length(uname))
    for (i in 1:length(uname)) {
      sel = which(meta.w.analysis$content ==uname[i])
      final_spread[1:length(sel),i] = meta.w.analysis[sel, term]
    }
    final_spread =  final_spread %>% data.frame()
    colnames(final_spread) = uname
    analysis_spread[[j]] = final_spread
  }
  names(analysis_spread) = terms
  return (analysis_spread)
}

