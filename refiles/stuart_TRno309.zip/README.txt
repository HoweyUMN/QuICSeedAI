Data files for RT-QuIC sample-level prediction of sample positivity

Compiled_Data.csv: First labeled data file from Stuart Lichtenberg on 11/8/22. First three rows indicate label (Pos/Neg), Sample Type (Soil, Obex, etc.), and a unique code that links RT-QuIC curves into replicate sets. Each column is a single time series corresponding to a well. Approximately 257*8 curves are labeled, for a total of 257 replicate sets. Two columns had their sample replicate ID manually renamed, per Stuart, in the most recent version of this file.

stuart_TRno307.CSV
stuart_TRno309.CSV
stuart_TRno310.CSV
Three different 384-well plates that have been labeled by Stuart, obtained 1/24/23.

Herbst_data.zip
Data as compiled by Allen Berbst at NWHC on 5/5/23. 
"Please find attached zipped data from 10 plates with various dilutions from 10-3->10-9. Within each plate the replicates are indicated by the assignment of a replicate number and their respective dilution. There are also two criteria (Slope and FL Gain) and if both of these are 1, we consider that the reaction has occurred."


