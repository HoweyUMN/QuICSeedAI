#' Get Combined Result
#'
#' @description This function takes a list of statistical results and returns a data frame summarizing the significance metrics.
#' The result includes the counts of occurrences of '*' in each row and adds a result column with '*' if the count is 3.
#'
#' @param stats A list of statistical results, each containing a 'significant' element.
#'              The names of the elements in 'stats' will be used as column names in the result.
#'              Output from GetStats function.
#' @param meta A cleaned metadata dataframe. Output from GetCleanMeta function
#' @return A data frame with columns corresponding to the elements in 'stats', a 'metric_count' column
#'         indicating the number of columns containing at least one '*', and a 'result' column containing
#'         '*' if 'metric_count' is 3, and '' otherwise.
#' @examples
#' \dontrun{
#' # Inputs for this function (stats and meta) are output from GetStats and GetCleanMeta, respectively. 
#' result_matrix <- GetCombinedResult(stats, meta)
#' print(result_matrix)
#' }
#'
#' @export
GetCombinedResult <- function(stats, meta) {
  
  col <- length(stats)
  row <- length(unique(meta$content))
  
  df_sig <- matrix("", ncol = col, nrow = row)
  rownames(df_sig) <- unique(meta$content)
  colnames(df_sig) <- c(names(stats))
  
  df_p = df_sig
  
  for (i in seq_along(stats)) {
    df_sig[, i] <- as.character(stats[[i]]$significant)
    if (('adj_p' %in% colnames (stats) )==TRUE) {
      df_p[, i] <- as.numeric(stats[[i]]$adj_p)
    } else {
      df_p[, i] <- as.numeric(stats[[i]]$p_value)
    }
  }
  
  df_sig <- df_sig[, -1]
  df_p <- df_p[,-1]
 
  metric_count <- apply(df_sig, 1, function(row) sum(grepl("\\*", row)))
 
  df_sig <- cbind(df_sig, metric_count = metric_count)
  df_p <- cbind(df_p, metric_count = metric_count)
  result <- ifelse(metric_count == 3, "*", "")
  
  df_p <- cbind(df_p, result = result)
  df_p <- as.data.frame(df_p, stringsAsFactors = FALSE)
  df_p$metric_count <- as.numeric(df_p$metric_count)
  
  return(df_p)
}
