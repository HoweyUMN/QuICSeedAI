#' Plot a Single Sample from the Data
#
#' @description This function takes a data frame and a sample name, and plots the values of the sample from the data.
#
#' @param data A data frame containing the data. This should include a column for each sample with the values for the analysis.
#' @param sample A string specifying the name of the sample to plot.
#' @importFrom graphics legend lines
#' @examples
#' \dontrun{
#' # Select sample
#' sample <- c('CT_pos')
#' 
#' # Use the data with the PlotRawSingle function on selected sample
#' # 'clean_raw_ct' is the output from GetCleanMeta()
#' PlotRawSingle(clean_raw_ct, sample)
#' }
#' @export
PlotRawSingle = function(data, sample) {
  time = as.numeric(rownames(data))
  sel = grep(sample, colnames(data))
  ymax = max(data[,sel])
  plot(x = time, y = data[,sel[1]], type = "l", col = 1, ylim = c(0,ymax/0.8),
       xlab = "Time (h)", ylab = "Fluorescence")
  for (i in 2:length(sel)) {
    lines(x = time, data[,sel[i]], type = "l", col = i)
  }
  legend("bottomright", legend=c(1:length(sel)),col=c(1:length(sel)), lty=1, cex=0.8)
}
