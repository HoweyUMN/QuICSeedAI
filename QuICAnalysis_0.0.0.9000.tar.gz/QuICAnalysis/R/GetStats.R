#' Perform Statistical Analysis on Spread Data
#'
#' @description This function takes a list of spread data frames and a control, performs various statistical tests (student's t-test, Wilcoxon rank-sum test, or robust t-test) comparing each column to the control, and returns the results.
#'
#' @param analysis_spread A list where each element is a data frame containing observations for different variables.
#' @param control A string that specifies the name of the control group column in the data frames.
#' @param test "t-test", "wilcox", or "yuen".
#' @param tail "two.sided", "greater", or "less".
#' @param adjust_p Logical indicating whether to adjust p-values for multiple comparisons. 
#' If `TRUE`, p-values are adjusted using the Benjamini-Hochberg procedure. 
#' If `FALSE`, original p-values are used. Default is `FALSE`.
#' @param alpha Significance level. Default is 0.05.
#' 
#' @return A list of data frames. Each data frame contains columns for the test statistic, p-value or adjusted p-value, 
#' and significance level (with asterisks) for each variable in the corresponding input data frame.
#' 
#' @examples
#' \dontrun{
#' # Define the control and use the data with the GetStats function; 
#' # analysis_spread_ct is output from GetSpreadData function.
#' control <- "CT_neg"
#' stats_ct <- GetStats(analysis_spread_ct, control, test = "yuen", tail = "greater")
#' print(stats_ct)
#' }
#' @importFrom WRS2 yuen
#' @importFrom stats wilcox.test p.adjust
#' @export
GetStats <- function(analysis_spread, control, test = 't-test', tail = 'two.sided', adjust_p = FALSE, alpha = 0.05) {
  
  analysis_stats <- vector(mode = 'list', length = length(analysis_spread))
  
  # Define the appropriate test function based on the 'test' argument
  if (test == "t-test") {
    test_fun <- function(x, y) err.t.test(x, y, alternative = tail)
  } else if (test == "wilcox") {
    test_fun <- function(x, y) wilcox.test(x, y, alternative = tail)
  } else if (test == "yuen") {
    test_fun <- function(x, y) yuen_wrapper(x, y, alternative = tail)
  } else {
    stop("Invalid test specified")
  }
  
  for (j in 1:length(analysis_spread)) {
    data <- analysis_spread[[j]]
    ct_sel <- grep(control, colnames(data))
    stat.res <- data.frame(matrix(NA, ncol = 4, nrow = ncol(data)))
    colnames(stat.res) <- c("statistic", "p_value", "adj_p","significant")
    
    for (i in 1:ncol(data)) {
      t.res <- test_fun(data[, i], data[, ct_sel])
      
      if (is.null(t.res)) {
        next
      } 
      
      # Adjust based on the structure of t.res
      if (is.atomic(t.res)) {
        # If t.res is atomic, assume it's the p-value
        p_value <- t.res
        statistic <- NA
      } else {
        p_value <- t.res$p.value
        statistic <- ifelse(test == "yuen", t.res$test, t.res$statistic)
      }
      
      stat.res[i, 1] <- round(statistic, digits = 2)
      stat.res[i, 2] <- round(p_value, digits = 5) 
    }
    
    # Adjust p-values if adjust_p is TRUE
    if (adjust_p) {
      p.adj <- p.adjust(stat.res[, 2], method = "BH")
      stat.res[, 3] <- round(p.adj, digits = 5) 
    } else {
      stat.res[, 3] <- stat.res[, 2]
    }
    
    for (i in 1:nrow(stat.res)) {
      pval <- stat.res[i, 3]
      if (!is.na(pval)) {
        if (pval <= 0.0001) {
          stat.res[i, 4] <- '****'
        } else if (pval <= 0.001) {
          stat.res[i, 4] <- '***'
        } else if (pval <= 0.01) {
          stat.res[i, 4] <- '**'
        } else if (pval <= alpha) {
          stat.res[i, 4] <- '*'
        } else {
          stat.res[i, 4] <- ''
        }
      }
    }
    
    stat.res[is.na(stat.res)] <- ""
    rownames(stat.res) <- colnames(data)
    if  (adjust_p == FALSE) {
      stat.res = stat.res[,-3]
    } else {
      stat.res = stat.res
    }
    analysis_stats[[j]] <- stat.res
    
  }
  
  names(analysis_stats) <- names(analysis_spread)
  return(analysis_stats)
}
