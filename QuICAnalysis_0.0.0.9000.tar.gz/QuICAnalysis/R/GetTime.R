#' Extract and Convert Time Data
#'
#' This function takes a dataframe with time data and extracts the time information 
#' from the second column. It then converts the time (if provided in "hours and minutes" format)
#' to decimal hours. If the time is not in "hours and minutes" format, it is converted to numeric.
#'
#' @param raw A dataframe where the second column contains time data, potentially in the format of "X h Y min" or as numeric values.
#'
#' @return A dataframe containing the time data in decimal hours or as numeric values.
#'
#' @examples
#' \dontrun{
#' # Example usage of GetTime with mock data
#' mock_data <- data.frame(ID = 1:3, Time = c("2 h 30 min", "1 h", "45 min"))
#' processed_time <- GetTime(mock_data)
#' print(processed_time)
#' }

#' @importFrom dplyr %>%
#' @export
GetTime <- function(raw) {
  time = c(raw[-1,2])
  time = unlist(time) %>% data.frame()
  if (grepl("min", time) == TRUE) {
    # Extract hours and minutes using regular expressions
    hours <- as.numeric(gsub(" h.*$", "", time$.))
    suppressWarnings({
      minutes <- ifelse(grepl("min", time$.), as.numeric(gsub("^.*?([0-9]+) min$", "\\1", time$.)), 0)
    })
    # Convert to decimal hours and return
    decimal_hours <- hours + (minutes / 60)
    time = (data.frame(decimal_hours = decimal_hours)) 
  }
  else {
    time$. = as.numeric(as.character(time$.))
  }
  return (time)
}

