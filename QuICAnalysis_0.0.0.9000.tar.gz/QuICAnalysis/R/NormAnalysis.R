#' Normalize Analysis Results
#'
#' @description This function takes metadata and analysis results, and normalizes the results based on a specified control.
#'
#' @param metadata A data frame containing the metadata. This should match the rows in the 'data' parameter.
#' @param data A data frame containing the results of the analysis. This should be the output from the `GetAnalysis` function.
#' @param control_name A string specifying the control to use for normalization. This should match one of the 'content' values in the metadata.
#' @return A data frame containing the normalized results of the analysis. This includes the TimeToThreshold, RAF, MPR, and MS for each row in the data, normalized based on the control.
#' @importFrom magrittr %>%
#' @examples
#' \dontrun{
#' # Combine the meta_ct and analysis_ct data; meta_ct and analysis_ct are 
#' # outputs from GetCleanMeta and GetAnalysis functions, respectively.
#' meta.w.analysis_ct <- cbind(meta_ct, analysis_ct)
#' control_name <- "CT_pos"
#' analysis_ct_norm <- NormAnalysis(metadata = meta_ct, 
#'                                  data = meta.w.analysis_ct, 
#'                                  control_name = control_name)
#' print(analysis_ct_norm)
#' }
#' @export
NormAnalysis = function(metadata, data, control_name) {
  sel = which(data$content == control_name) %>% as.numeric()
  data_pos = data[sel,]
  terms = c('TimeToThreshold', 'RAF', 'MPR','MS')
  data_norm = data.frame(matrix(nrow = nrow(data), ncol = length(terms)))
  for (i in 1:length(terms)) {
    ave_terms = mean(data_pos[,terms[i]])
    data_norm[,i] = data[,terms[i]]/ave_terms
  }
  colnames(data_norm) = terms
  data_norm = cbind(metadata, data_norm)
  return (data_norm)
}
