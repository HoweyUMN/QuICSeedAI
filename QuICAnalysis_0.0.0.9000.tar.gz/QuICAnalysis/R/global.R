# globals.R

# Inform R's checking mechanism of global variables
utils::globalVariables("AlternativeTime")