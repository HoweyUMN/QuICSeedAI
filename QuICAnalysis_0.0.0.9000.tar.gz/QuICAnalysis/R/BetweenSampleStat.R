#' Perform a t-test Between Two Samples
#'
#' @description This function takes a data frame, two sample names, and an analysis term, and performs various statistical tests (student's t-test, Wilcoxon Rank-Sum Test, or Yuen's t-test) comparing the values of the term for the two samples.
#' @param data A data frame with metadata and analysis data. This should include a 'content' column with the sample names, and a column for the specified term with the values for the analysis.
#' @param sample_1 A string specifying the name of the first sample to compare. This should be exactly as appeared in the 'content' column of data.
#' @param sample_2 A string specifying the name of the second sample to compare. This should be exactly as appeared in the 'content' column of data.
#' @param term A string specifying the name of the column in the data frame that contains the values for the analysis, choosing one from 'RAF', 'MS', 'TimeToThreshold', and 'MPR'. 
#' @return The result of the various statistical tests (student's t-test, Wilcoxon Rank-Sum Test, or Yuen's t-test) function comparing the values of the term for the two samples.
#' @param term Character string specifying the column name in the data from which samples are to be extracted.
#' @param test Character string specifying the type of statistical test to be performed. Options include "t-test", "wilcox", and "yuen".
#' @param alternative Character string specifying the alternative hypothesis. It determines the kind of p-value calculation for the chosen test. Options include "two.sided", "less", and "greater".
#' 
#' @examples
#' \dontrun{
#' BetweenSampleStat(data = meta.w.analysis_ct, 
#'                          sample_1 = 'CT_pos', 
#'                          sample_2 = 'CT_neg', 
#'                          term = 'RAF',  
#'                          test = "wilcox", 
#'                          alternative = "two.sided")
#' }
#' @importFrom dplyr select filter any_of
#' @importFrom stats wilcox.test
#' @importFrom WRS2 yuen 
#' @export
BetweenSampleStat <- function(data, sample_1, sample_2, term, test = "t-test", alternative = "two.sided") {
  data = dplyr::select(data, any_of(c('content', term)))
  data_1 = dplyr::filter(data, data$content == sample_1)
  data_1 = c(data_1[,term])
  data_2 = dplyr::filter(data, data$content == sample_2)
  data_2 = c(data_2[,term])
  
  # Create a matrix from the provided vectors
  max_len <- max(length(data_1), length(data_2))
  mat <- matrix(NA, nrow=max_len, ncol=2)
  colnames(mat) <- c("group1", "group2")
  mat[1:length(data_1), 1] <- data_1
  mat[1:length(data_2), 2] <- data_2
  
  if (test == "t-test") {
    t.res = err.t.test(data_1, data_2, alternative = alternative)
  } else if (test == "wilcox") {
    t.res = wilcox.test(data_1, data_2, alternative = alternative)
  } else if (test == "yuen") {
    t.res = yuen_wrapper(mat[,1], mat[,2], alternative)
  } else {
    stop("Invalid test specified. Choose 't-test', 'wilcox', or 'yuen'.")
  }
  
  return(t.res)
}

