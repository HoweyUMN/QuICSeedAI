#' Plot Multiple Samples from the Data
#'
#' @description This function takes a data frame and a vector of sample names, and plots the values of the samples from the data.
#' @param data A data frame containing the data. This should include a column for each sample with the values for the analysis.
#' @param samples A vector of strings specifying the names of the samples to plot.
#' @importFrom graphics plot legend lines
#' @examples
#' \dontrun{
#' # Define the samples
#' samples <- c('CT_pos','Cu_641','Zn_614')
#'
#' # Combine the clean raw data generated previously from GetCleanRaw()
#' raw_all <- bind_cols(clean_raw_ct, clean_raw_metal)
#'
#' # Use the data with the PlotRawMulti function
#' PlotRawMulti(raw_all, samples)
#' }
#' @export
PlotRawMulti = function(data, samples) {
  time = as.numeric(rownames(data))
  
  original_colnames <- colnames(data)
  
  data_copy <- data
  
  # Loop over each column
  for (i in seq_len(ncol(data))) {
    # If the column is character, convert it to numeric
    if (is.character(data[[i]])) {
      data_copy[[i]] <- as.numeric(data[[i]])
    }
  }
  
  # Assign the original column names back to the data
  colnames(data_copy) <- original_colnames
  
  ymax = c()
  for (j in 1:length(samples)) {
    sel = grep(samples[j], colnames(data_copy))
    if (length(sel) > 0) {
      ymax[j] = max(data_copy[,sel])
    }
  }
  ymax = if (length(ymax) > 0) max(ymax) else 0
  sel = grep(samples[1], colnames(data_copy))
  if (length(sel) > 0) {
    graphics::plot(x = time, y = data_copy[,sel[1]], type = "l", col = 1, ylim = c(0, ymax/0.8),
                   xlab = "Time (h)", ylab = "Fluorescence")
    for (i in 2:length(sel)) {
      graphics::lines(x = time, y = data_copy[,sel[i]], type = "l", col = 1)
    }
  }
  for (j in 2:length(samples)) {
    sel = grep(samples[j], colnames(data_copy))
    if (length(sel) > 0) {
      for (i in 1:length(sel)) {
        graphics::lines(x = time, y = data_copy[,sel[i]], type = "l", col = j)
      }
    }
  }
  legend("topleft", legend=samples, col=c(1:length(samples)), lty=1, cex=0.8)
}

