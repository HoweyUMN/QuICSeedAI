#' Wrapper for Yuen's t-test with Long Format Data Conversion
#'
#' This function takes two numeric vectors, converts them into a long-format data frame, 
#' and then performs Yuen's t-test. It also supports one-sided tests by adjusting the resulting p-value.
#'
#' @param x A numeric vector for group 1.
#' @param y A numeric vector for group 2.
#' @param alternative A string indicating the type of test to be conducted. 
#' Valid values are "two.sided", "less", and "greater". Default is "two.sided".
#'
#' @return A list containing results of Yuen's t-test. If an error occurs during the test, 
#' it either returns NULL or a message indicating the nature of the error.
#' @importFrom WRS2 yuen
#' @importFrom tidyr pivot_longer everything
#' @export
yuen_wrapper <- function(x, y, alternative = "two.sided") {
 
  data <- data.frame(group1 = x, group2 = y)
  
  long_data <- tidyr::pivot_longer(data, cols = everything(), names_to = "group", values_to = "value")
  
  result <- tryCatch({
    res <- WRS2::yuen(value ~ group, data = long_data, tr = 0.1)
    
    if (alternative == "greater" && res$test > 0) {
      res$p.value <- res$p.value / 2
    } else if (alternative == "less" && res$test < 0) {
      res$p.value <- res$p.value / 2
    }
    
    return(res)
    
  }, error = function(e) {
    if(grepl("missing value where TRUE/FALSE needed", e$message)) {
      return(NULL)  
    } else {
      return(paste("Error:", e$message))
    }
  })
  
  return(result)
}