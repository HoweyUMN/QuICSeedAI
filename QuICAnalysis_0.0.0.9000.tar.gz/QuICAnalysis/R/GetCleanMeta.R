#' Generate Clean Metadata
#'
#' @description This function takes raw data, plate information, and replicate information to generate clean metadata.
#'
#' @param raw A dataframe containing raw data where columns represent wells. The first two columns are not used in the analysis.
#' @param plate Setup of the plate in terms of sample names. 
#' @param replicate Setup of the plate in terms of sample replicates. 
#' 
#' @return A cleaned metadata dataframe.
#' @examples
#' data(raw_ct)
#' data(plate_ct)
#' data(replicate_ct)
#' meta_ct <- GetCleanMeta(raw_ct, plate_ct, replicate_ct)
#' @importFrom tidyr drop_na
#' @export
GetCleanMeta = function(raw, plate, replicate) {
  n_platecol <- ifelse(ncol(plate) == 13, 13, 25)
  replicate = replicate[,-1]
  replicate = c(t(replicate))
  wells = 1:length(replicate)
  #well
  well = colnames(raw[-c(1:2)])
  well = well[wells]
  
  content = plate[,2:n_platecol]
  content = c(t(content))
  content = content[wells]
  content_replicate = paste(content, replicate, sep = '_') 
  
  meta = data.frame(
    well = well,
    content = content,
    replicate = replicate,
    content_replicate)
  if (n_platecol == 13) {
    meta$format = 96
  } else {
    meta$format = 384
  }
  meta =  drop_na(meta)
  
  return (meta)
}

