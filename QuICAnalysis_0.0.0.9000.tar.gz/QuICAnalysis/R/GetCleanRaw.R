#' Generate Clean Raw Data
#'
#' @description This function takes metadata, raw data, and total cycle information to generate clean raw fluorescence data.
#'
#' @param meta A data frame containing the metadata. Output from GetCleanMeta function.
#' @param raw Raw fluorescence readings from MARS software.
#' @param cycle_total Total number of run cycles. 
#' @return A data frame containing the cleaned raw fluorescence data. 
#' @importFrom magrittr %>%
#' @examples
#' \dontrun{
#' cycle_total <- 65 
#' AlternativeTime = GetTime(raw_ct)
#' clean_raw_ct <- GetCleanRaw(meta_ct, raw_ct, cycle_total)
#' }
#' @export
GetCleanRaw = function (meta, raw, cycle_total) {
  if (missing(cycle_total) || is.null(cycle_total) || length(cycle_total) == 0) {
    cycle_total =  nrow(raw) - 1
  } else {
    # other logic here, maybe:
    cycle_total <- cycle_total
  }
  raw = raw[-1,-c(1:2)]
  raw = raw[,1:nrow(meta)]
  raw = as.numeric(unlist(raw))
  raw = matrix(raw, nrow = cycle_total) 
  rownames(raw) = unlist(AlternativeTime)
  colnames(raw) = meta$content_replicate
  return(raw)
}
