#' Perform Analysis on Raw Data
#'
#' @description This function takes cleaned raw data and performs various analyses, including calculating the Rate of Amyloid Formation (RAF), Max Point Ratio (MPR), and Max Slope (MS).
#'
#' @param raw Cleaned raw data. Output from the `GetCleanRaw` function.
#' @param sd.fold Fold of standard deviation to calculate the threshold for RAF.
#' @param cycle_background The number of cycle chosen as the background for the RAF and MPR calculations.
#' @param binw A numeric value indicating the bin width for the MS calculation.
#' @return A data frame containing the results of the analysis. This includes the TimeToThreshold, RAF, MPR, and MS for each column in the raw data.
#' @importFrom magrittr %>%
#' @importFrom stats sd
#' @examples
#' \dontrun{
#' # Define the parameters and use the data with the GetAnalysis function. 
#' # clean_raw_ct and clean_raw_metal are the output from GetCleanRaw function.
#' analysis_ct = GetAnalysis(clean_raw_ct, sd.fold = 10, cycle_background = 1,  binw=4)
#' print(analysis_ct)
#' 
#' analysis_Cu = GetAnalysis(clean_raw_metal[1:48], sd.fold = 10, cycle_background = 1,  binw=4)
#' print(analysis_Cu)
#' 
#' analysis_Zn = GetAnalysis(clean_raw_metal[49:96], sd.fold = 10, cycle_background = 1,  binw=4)
#' print(analysis_Zn)
#' }
#' @export
GetAnalysis = function (raw, sd.fold, cycle_background, binw) { 
 
  nv = as.numeric(raw[cycle_background, ])
  threshold = mean(nv) + sd.fold*sd(nv)
  

  TimeToThreshold = apply(raw, 2, function(column) {
    limited_column = column[-(1:5)]
    crossing_row = which(limited_column > threshold)[1]
    
    if (is.na(crossing_row)) {
      return(0)
    } else {
      return(rownames(raw)[crossing_row + 5])
    }
  })
  
  TimeToThreshold = as.numeric(TimeToThreshold)
  RAF = 1/TimeToThreshold
  RAF[is.infinite(RAF)] <- 0
  
  
  #Max Point Ratio (MPR)
  background = raw[cycle_background,]
  MP = data.frame()
  for (i in 1:ncol(raw)) {
    MP[1,i] = max(raw[,i])
  }
  MPR = t(MP/background )%>% as.numeric()
  
  #Max Slope (MS)
  #calculate moving slope
  binw = binw
  offset = 1
  Smoothed_Slope = data.frame()
  for (i in 1:ncol(raw)) {
    for (j in offset:(nrow(raw)-binw)) {
      v2 = as.numeric(raw[(j+binw),i])
      v1 = as.numeric(raw[j,i])
      Smoothed_Slope[j-(offset-1),i] = (v2-v1)/binw
    }
  }
  MS = data.frame()
  for (i in 1:ncol(Smoothed_Slope)) {
    MS[1,i] = max(Smoothed_Slope[,i])
  }
  MS = t(MS) %>% as.numeric()
  
  analysis= data.frame(
    TimeToThreshold = TimeToThreshold,
    RAF= RAF,
    MPR = MPR,
    MS = MS)
  
  return(analysis)
}
