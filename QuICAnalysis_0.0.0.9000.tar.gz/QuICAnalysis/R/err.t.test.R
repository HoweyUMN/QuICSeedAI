#' Perform a t-test with Error Handling
#'
#' @description This function performs a t-test on the provided data, and returns NA if an error occurs during the test.
#' @param x A (non-empty) numeric vector of data values.
#' @param y An optional (non-empty) numeric vector of data values.
#' @param ... Other parameters used for t.test. 
#' @importFrom methods is
#' @importFrom stats sd t.test na.omit
#' @return The result of the t.test function if it completes successfully, or NA if an error occurs.
err.t.test <- function(x, y, ...) {
  x <- na.omit(x)
  y <- na.omit(y)
  obj <- try(t.test(x, y, ...), silent=TRUE)
  if (is(obj, "try-error")) return(NA) else return(obj)
}

